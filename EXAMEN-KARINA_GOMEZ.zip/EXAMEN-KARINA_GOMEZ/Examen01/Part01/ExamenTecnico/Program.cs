﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenTecnico
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            ChangeString Pregunta1 = new ChangeString();
            String Resultado = Pregunta1.Build("**Casa 52");
            Console.WriteLine("----- Pregunta 1 -----");
            Console.WriteLine(Resultado);

            CompleteRange Pregunta2 = new CompleteRange();
            int[] Range = { 4, 2, 9 };
            Range = Pregunta2.Build(Range);

            MoneyParts Pregunta3 = new MoneyParts();
            decimal[][] dResultado;
            dResultado = Pregunta3.Build((decimal)10.50);
            
        }
    }
}
