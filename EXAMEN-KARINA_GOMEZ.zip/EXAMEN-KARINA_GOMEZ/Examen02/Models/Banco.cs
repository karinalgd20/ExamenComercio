﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Examen02.Models
{
    public class Banco
    {

        [Key]
        public int IdBanco { get; set; }

        [StringLength(200, ErrorMessage = "The field {0} must contain between {2} and {1} characters", MinimumLength = 1)]
        public String Nombre { get; set; }

        [StringLength(200, ErrorMessage = "The field {0} must contain between {2} and {1} characters", MinimumLength = 1)]
        public String Direccion { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha Registro")]
        public DateTime FecRegistro { get; set; }

    }
}