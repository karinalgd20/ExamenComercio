﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Examen02.Models
{
    public class Estado
    {
        [Key]
        public int IdEstado { get; set; }

        [StringLength(50, ErrorMessage = "The field {0} must contain between {2} and {1} characters", MinimumLength = 1)]
        [Display(Name = "Descripción")]
        public String Descripcion { get; set; }

    }
}