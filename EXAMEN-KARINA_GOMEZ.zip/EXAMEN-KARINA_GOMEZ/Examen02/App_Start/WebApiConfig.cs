﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web.Http;

namespace Examen02
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            var formatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            formatter.SerializerSettings.ContractResolver =
                new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );


            config.Routes.MapHttpRoute(
                name: "JsonOrden",
                routeTemplate:  "JsonOrden/{id}",
                defaults: new { controller = "Json", action = "Orden", id = RouteParameter.Optional } //or whatever your controller name is
               
            );

            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/json"));


            config.Routes.MapHttpRoute(
                name: "XmlSucursal",
                routeTemplate: "XmlSucursal/{id}",
                defaults: new { controller = "Xml", action = "SucursalXml", id = RouteParameter.Optional } //or whatever your controller name is

            );

            config.Formatters.XmlFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/xml"));

            
        }
    }
}
