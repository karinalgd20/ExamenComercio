﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using Examen02.Models;
using System.Configuration;
using System.Data.Common;
using System.Reflection; 

namespace Examen02.DataAccess
{
    public class SucursalDO
    {
        #region Variables

        DatabaseProviderFactory factory = new DatabaseProviderFactory();
        Util util = new Util();

        #endregion

        #region Metodos

        public List<Sucursal> GetSucursalByBanco(int Id)
        {
            List<Sucursal> objGetSucursal = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_SUCURSAL_BANCO");

            db.AddInParameter(cmd, "@IdBanco", DbType.Int32, Id);

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetSucursal = util.ConvertTo<Sucursal>(dataTable);
            }

            return objGetSucursal;
        }

        public List<Sucursal> GetSucursalList()
        {
            List<Sucursal> objGetSucursal = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_SUCURSALES");

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetSucursal = util.ConvertTo<Sucursal>(dataTable);
            }

            return objGetSucursal;
        }

        public Sucursal GetSucursalListById(int IdBanco)
        {
            Sucursal objGetSucursal = new Sucursal();
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_SUCURSAL_ID");

            db.AddInParameter(cmd, "@ID", DbType.Int32, IdBanco);

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetSucursal.IdSucursal = int.Parse(dataTable.Rows[0]["IdSucursal"].ToString());
                objGetSucursal.IdBanco = int.Parse(dataTable.Rows[0]["IdBanco"].ToString());
                objGetSucursal.Nombre = dataTable.Rows[0]["Nombre"].ToString();
                objGetSucursal.Direccion = dataTable.Rows[0]["Direccion"].ToString();
                objGetSucursal.FecRegistro = DateTime.Parse(dataTable.Rows[0]["FecRegistro"].ToString());
            }

            return objGetSucursal;
        }


        public void Mant(Sucursal oEnt, int Opcion)
        {
            var db = factory.Create("Cn");
            
            db.ExecuteNonQuery("SP_MANT_SUCURSAL", new object[] { oEnt.IdSucursal, oEnt.IdBanco, oEnt.Nombre, oEnt.Direccion, oEnt.FecRegistro, Opcion });
        }

        #endregion


    }
}