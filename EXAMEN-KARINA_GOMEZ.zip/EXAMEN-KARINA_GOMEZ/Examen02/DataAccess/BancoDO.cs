﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using Examen02.Models;
using System.Configuration;  
using System.Data.Common;  
using System.Reflection; 

namespace Examen02.DataAccess
{
    public class BancoDO
    {

        DatabaseProviderFactory factory = new DatabaseProviderFactory();
        Util util = new Util();

        public List<Banco> GetBancoList()  
        {  
            List<Banco> objGetBanco = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_BANCOS");
            
            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])  
                {  
                    objGetBanco = util.ConvertTo<Banco>(dataTable);  
                }

            return objGetBanco;
         }

        public Banco GetBancoListById(int IdBanco)
        {
            Banco objGetBanco = new Banco();
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_BANCOS_ID");
            
            db.AddInParameter(cmd, "@ID", DbType.Int32, IdBanco);  
            
            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetBanco.IdBanco = int.Parse( dataTable.Rows[0]["IdBanco"].ToString());
                objGetBanco.Nombre = dataTable.Rows[0]["Nombre"].ToString();
                objGetBanco.Direccion = dataTable.Rows[0]["Direccion"].ToString();
                objGetBanco.FecRegistro = DateTime.Parse(dataTable.Rows[0]["FecRegistro"].ToString());   
            }

            return objGetBanco;
        }


        public void Mant(Banco oEnt, int Opcion)
        {
            var db = factory.Create("Cn");
            
            db.ExecuteNonQuery("SP_MANT_BANCOS", new object[] { oEnt.IdBanco, oEnt.Nombre, oEnt.Direccion, oEnt.FecRegistro, Opcion });
        }


    }
}