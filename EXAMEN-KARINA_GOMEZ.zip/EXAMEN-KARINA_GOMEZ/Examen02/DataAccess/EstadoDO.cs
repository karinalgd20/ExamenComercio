﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using Examen02.Models;
using System.Configuration;
using System.Data.Common;
using System.Reflection; 

namespace Examen02.DataAccess
{
    public class EstadoDO
    {

        DatabaseProviderFactory factory = new DatabaseProviderFactory();
        Util util = new Util();

        public List<Estado> GetEstadoList()
        {
            List<Estado> objGetEstado = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_ESTADOS");

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetEstado = util.ConvertTo<Estado>(dataTable);
            }

            return objGetEstado;
        }
    }
}